package com.example.demoCache.services;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

@Service
public class DataService 
{
    @Cacheable("hii")
    public
    String getData(String param)
    {
         try
         {
             Thread.sleep(10000);
         }
         catch(InterruptedException i)
         {
            System.out.println(i);
         }
         return "Result for"+ param;
    }
}
